package org.knowm.xchart.style.colors;

import java.awt.*;

/** @author timmolter */
public interface SeriesColors {

  Color[] getSeriesColors();
}
